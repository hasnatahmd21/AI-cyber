# Gate 0 - Legacy inventory

Source: `IT_tech__MERGED_ALL_FIXES_APPLIED.py` (87018 lines, sha256 `7cad46a475a5eaa3...`)

| Phase | File | Classes | Functions | Imports | SQLite | File I/O | `__main__` entry | Tests |
|---|---|---|---|---|---|---|---|---|
| 1 | `phase_01_operating_system_security_depth.py` | 41 | 80 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 44 passed / 0 failed |
| 2 | `phase_02_network_security_state_depth.py` | 37 | 67 | __future__, collections, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 44 passed / 0 failed |
| 3 | `phase_03_identity_dynamic_authority.py` | 24 | 71 | __future__, dataclasses, datetime, enum, fnmatch, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 49 passed / 0 failed |
| 4 | `phase_04_application_api_trust_state.py` | 35 | 73 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 46 passed / 0 failed |
| 5 | `phase_05_container_virtualization_cloud_state.py` | 38 | 71 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 41 passed / 0 failed |
| 6 | `phase_06_distributed_security_state.py` | 28 | 71 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 49 passed / 0 failed |
| 7 | `phase_07_software_supply_chain_trust_continuity.py` | 31 | 82 | __future__, dataclasses, datetime, enum, hashlib, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 49 passed / 0 failed |
| 8 | `phase_08_ai_supply_chain_trust.py` | 36 | 96 | __future__, dataclasses, datetime, enum, hashlib, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 58 passed / 0 failed |
| 9 | `phase_09_storage_database_security_state.py` | 39 | 87 | __future__, dataclasses, datetime, enum, hashlib, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 49 passed / 0 failed |
| 10 | `phase_10_hardware_firmware_boot_trust.py` | 36 | 92 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 50 passed / 0 failed |
| 11 | `phase_11_statistical_security_foundation.py` | 21 | 83 | __future__, dataclasses, datetime, enum, json, math, os, random, sqlite3, tempfile, traceback, typing | yes | - | yes | 66 passed / 0 failed |
| 12 | `phase_12_adaptive_behavioral_security.py` | 29 | 63 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 43 passed / 0 failed |
| 13 | `phase_13_multivariate_security_state_analytics.py` | 23 | 58 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 42 passed / 0 failed |
| 14 | `phase_14_time_series_early_warning_extension.py` | 24 | 58 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 42 passed / 0 failed |
| 15 | `phase_15_probabilistic_security_extension.py` | 25 | 87 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 71 passed / 0 failed |
| 16 | `phase_16_detection_error_science.py` | 29 | 91 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 72 passed / 0 failed |
| 17 | `phase_17_causal_security_extension.py` | 24 | 66 | __future__, collections, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 49 passed / 0 failed |
| 18 | `phase_18_counterfactual_security_extension.py` | 22 | 68 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 50 passed / 0 failed |
| 19 | `phase_19_defensive_intervention_optimization.py` | 23 | 67 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 52 passed / 0 failed |
| 20 | `phase_20_cyber_control_theory_extension.py` | 20 | 77 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 60 passed / 0 failed |
| 21 | `phase_21_security_invariants_formal_verification.py` | 23 | 69 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 48 passed / 0 failed |
| 22 | `phase_22_reliability_failure_engineering.py` | 24 | 70 | __future__, collections, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 54 passed / 0 failed |
| 23 | `phase_23_adversarial_resilience.py` | 41 | 100 | __future__, collections, dataclasses, datetime, enum, hashlib, json, math, os, random, sqlite3, tempfile, traceback, typing | yes | - | yes | 71 passed / 0 failed |
| 24 | `phase_24_cross_layer_security_causality.py` | 24 | 70 | __future__, collections, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 51 passed / 0 failed |
| 25 | `phase_25_cyber_digital_twin_extension.py` | 24 | 64 | __future__, collections, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 48 passed / 0 failed |
| 26 | `phase_26_autonomous_system_ai_agent_security.py` | 32 | 83 | __future__, base64, collections, dataclasses, datetime, enum, json, os, re, sqlite3, tempfile, traceback, typing | yes | - | yes | 58 passed / 0 failed |
| 27 | `phase_27_ai_governance_technical_enforcement.py` | 29 | 68 | __future__, collections, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 55 passed / 0 failed |
| 28 | `phase_28_ai_dependency_sovereignty_concentration.py` | 28 | 83 | __future__, collections, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 61 passed / 0 failed |
| 29 | `phase_29_novel_attack_surface_discovery.py` | 23 | 79 | __future__, collections, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 56 passed / 0 failed |
| 30 | `phase_30_emergent_threat_discovery.py` | 27 | 84 | __future__, collections, dataclasses, datetime, enum, itertools, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 64 passed / 0 failed |
| 31 | `phase_31_cryptographic_future_resilience.py` | 30 | 81 | __future__, collections, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 62 passed / 0 failed |
| 32 | `phase_32_emerging_technology_security_forecasting.py` | 29 | 59 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 44 passed / 0 failed |
| 33 | `phase_33_future_threat_scenario_engineering.py` | 34 | 66 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 48 passed / 0 failed |
| 34 | `phase_34_defensive_technology_invention_pipeline.py` | 30 | 81 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 58 passed / 0 failed |
| 35 | `phase_35_cross_domain_security_fabric.py` | 21 | 60 | __future__, collections, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 47 passed / 0 failed |
| 36 | `phase_36_multi_model_assurance.py` | 25 | 73 | __future__, collections, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 57 passed / 0 failed |
| 37 | `phase_37_security_outcome_control_effectiveness_s.py` | 29 | 89 | __future__, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 67 passed / 0 failed |
| 38 | `phase_38_adversarial_validation.py` | 24 | 59 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 44 passed / 0 failed |
| 39 | `phase_39_global_integration_validation.py` | 20 | 60 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 47 passed / 0 failed |
| 40 | `phase_40_complete_testing.py` | 29 | 81 | __future__, concurrent, dataclasses, datetime, enum, json, math, os, sqlite3, tempfile, threading, time, traceback, typing | yes | - | yes | 47 passed / 0 failed |
| 41 | `phase_41_static_runtime_quality.py` | 20 | 80 | __future__, ast, builtins, dataclasses, datetime, enum, importlib, json, os, random, re, sqlite3, sys, tempfile, threading, time, traceback, typing | yes | yes | yes | 48 passed / 0 failed |
| 42 | `phase_42_final_hardening_technology_verification.py` | 23 | 64 | __future__, dataclasses, datetime, enum, json, os, sqlite3, tempfile, traceback, typing | yes | - | yes | 47 passed / 0 failed |

Total symbols mapped: 4305.

## Findings
- Spec says 27 phases; the file actually contains **42 phase modules** (43 segments: Phase 3 appears twice, byte-identical). All 42 preserved; the duplicate is stored once and recorded in `split_manifest.json`.
- Phases are independent single-file modules (own contracts/stores/tests); there is no cross-phase import. In the monolith they shared one namespace and one `from __future__ import annotations`; Phase 13 relied on that (it used `Sequence` before importing it) so each split file received that one line (recorded in the manifest; stripped on reassembly check).
- Alternate entry points: every phase file has an `if __name__ == '__main__'` test runner. Canonical entry is `python -m ai_cyber`.
- Shared mutable state / side effects: phases use in-memory and SQLite stores created by the caller; no network access.
