"""AI-CYBER layered defence system."""
__version__ = "1.0.0"
